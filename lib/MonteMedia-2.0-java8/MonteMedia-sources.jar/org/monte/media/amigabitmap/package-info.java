/* @(#)package-info.java
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */

/**
 * Provides classes for representing Amiga bitmap images.
 * <p>
 * Reference:<br>
 * Commodore-Amiga, Inc. (1991) Amiga ROM Kernel Reference Manual. Devices.
 * Third Edition. Reading: Addison-Wesley.
 * 
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
package org.monte.media.amigabitmap;

