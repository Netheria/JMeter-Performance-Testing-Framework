/* @(#)RunLengthCodecSpi.java
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */

package org.monte.media.avi.codec.video;

import org.monte.media.av.CodecSpi;

/**
 * RunLengthCodecSpi.
 *
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
public class RunLengthCodecSpi implements CodecSpi {

    @Override
    public RunLengthCodec create() {
       return new RunLengthCodec();
    }

}
