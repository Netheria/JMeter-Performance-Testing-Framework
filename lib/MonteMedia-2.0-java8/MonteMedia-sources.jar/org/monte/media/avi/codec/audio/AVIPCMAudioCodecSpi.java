/* @(#)AVIPCMAudioCodecSpi.java
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */

package org.monte.media.avi.codec.audio;

import org.monte.media.av.CodecSpi;

/**
 * AVIPCMAudioCodecSpi.
 *
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
public class AVIPCMAudioCodecSpi implements CodecSpi {

    @Override
    public AVIPCMAudioCodec create() {
       return new AVIPCMAudioCodec();
    }

}
