/* @(#)package-info.java
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */
/**
 * Provides AVI-specific video codecs.
 * 
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
package org.monte.media.avi.codec.video;

