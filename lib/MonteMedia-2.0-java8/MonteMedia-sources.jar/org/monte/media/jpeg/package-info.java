/* @(#)package-info.java
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */
/**
 * Provides media handlers for JPEG images with CMYK colors.
 * 
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
package org.monte.media.jpeg;

