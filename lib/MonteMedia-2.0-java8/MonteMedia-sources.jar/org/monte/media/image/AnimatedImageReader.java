/* @(#)AnimatedImageReader
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */
package org.monte.media.image;

import java.awt.Image;
import java.io.IOException;

/**
 * AnimatedImageReader.
 *
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
public interface AnimatedImageReader {

    /**
     * Reads an animated image.
     * @param index the image index
     * @return an animated image
     * @throws IOException if reading fails
     */
    Image readAnimatedImage(int index) throws IOException;
}
