/* @(#)TechSmithCodecSpi.java
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */

package org.monte.media.av.codec.video;

import org.monte.media.av.CodecSpi;

/**
 * TechSmithCodecSpi.
 *
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
public class TechSmithCodecSpi implements CodecSpi {

    @Override
    public TechSmithCodec create() {
       return new TechSmithCodec();
    }

}
