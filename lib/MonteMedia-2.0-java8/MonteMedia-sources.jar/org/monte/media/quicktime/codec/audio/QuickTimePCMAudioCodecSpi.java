/* @(#)QuickTimePCMAudioCodecSpi.java
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */

package org.monte.media.quicktime.codec.audio;

import org.monte.media.av.CodecSpi;

/**
 * QuickTimePCMAudioCodecSpi.
 *
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
public class QuickTimePCMAudioCodecSpi implements CodecSpi {

    @Override
    public QuickTimePCMAudioCodec create() {
       return new QuickTimePCMAudioCodec();
    }

}
