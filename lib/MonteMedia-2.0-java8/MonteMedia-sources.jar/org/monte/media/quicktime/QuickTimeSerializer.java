/* @(#)QuickTimeSerializer.java
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */
package org.monte.media.quicktime;

/**
 * {@code QuickTimeSerializer} takes a {@code QuickTimeMovie} and flattens
 * it into an {@code ImageOutputStream}.
 *
 * This is in internal class of QuickTimeOutputStream.
 *
 * FIXME - Implement me.
 * 
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
public class QuickTimeSerializer {

}
