/* @(#)module-info.java
 * Copyright © 2017 Werner Randelshofer, Switzerland. MIT License.
 */

/**
 * Movie maker demo.
 * 
 * @author Werner Randelshofer
 * @version $Id: 5afe851 2017-08-10T13:50:23+02:00 Werner Randelshofer $
 */
module org.monte.demo.moviemaker {
    requires java.desktop;
    requires java.prefs;
    
    requires org.monte.media;    
    
    exports org.monte.demo.moviemaker;    
}
